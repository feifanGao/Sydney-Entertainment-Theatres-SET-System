# How to compile in Linux/Unix:
    $ ./build.sh

# How to compile in Windows:
    $ build

# How to run in Linux/Unix:
    $ java -cp bin:./postgresql-42.2.5.jar Presentation.BookingTrackerFrame

# How to run in Windows:
    $ java -cp bin;postgresql-42.2.5.jar Presentation.BookingTrackerFrame
