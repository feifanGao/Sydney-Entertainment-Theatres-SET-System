rm -rf bin
mkdir bin
javac -cp ./postgresql-42.2.5.jar src/*/*.java -d bin
